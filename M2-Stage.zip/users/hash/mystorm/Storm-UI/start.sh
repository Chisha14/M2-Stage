#!/bin/sh
/configure.sh
${HASH_MYSTORM_ZOOKEEPER_SERVICE_HOST:-$1} ${HASH_MYSTORM_NIMBUS_SERVICE_HOST:-$2}
exec bin/storm ui
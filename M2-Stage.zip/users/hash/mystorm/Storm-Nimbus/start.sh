#!/bin/sh
/configure.sh
${HASH_MYSTORM_ZOOKEEPER_SERVICE_HOST:-$1}
exec bin/storm nimbus
#!/bin/sh
/configure.sh
${STORM-HASH-TESTSTORMM-ZOOKEEPER_SERVICE_HOST:-$1}
exec bin/storm nimbus
#!/bin/sh

yes | service ssh start

echo sleep for eternity.
while : ; do sleep 1 ; done

sleep 5
ls -l ./

echo sleeping 10 secs

sleep 10

echo finished sleeping

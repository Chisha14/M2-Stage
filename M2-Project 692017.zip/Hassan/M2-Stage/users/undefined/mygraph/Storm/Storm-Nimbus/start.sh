#!/bin/sh
/configure.sh ${GRAPH_UNDEFINED_MYGRAPH_ZOOKEEPER_SERVICE_HOST:-$1}
exec bin/storm nimbus
#!/bin/sh
/configure.sh ${GRAPH_UNDEFINED_GRAPHY_ZOOKEEPER_SERVICE_HOST:-$1}
exec bin/storm nimbus
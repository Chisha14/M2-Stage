#!/bin/sh

#cat >> config/kibana.yml <<EOF

#server.port: 5601
#server.host: "localhost"
#elasticsearch.url: "http://localhost:9200"
#kibana.index: ".kibana"
#elasticsearch.preserveHost: true

#EOF

#exec /usr/local/kibana/bin/kibana
service logstash start
update-rc.d logstash defaults 96 9
#service logstash start

while :
do
sleep 1
done
